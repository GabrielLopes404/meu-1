import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Palette, Image, Box, Monitor, Sparkles } from "lucide-react";
import type { Service } from "@shared/schema";

const iconMap: Record<string, any> = {
  palette: Palette,
  image: Image,
  box: Box,
  monitor: Monitor,
  sparkles: Sparkles,
};

export function Services() {
  const { data: services = [], isLoading } = useQuery<Service[]>({
    queryKey: ["/api/services"],
  });

  if (isLoading) {
    return (
      <section id="servicos" className="py-20 md:py-32 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="h-12 w-64 mx-auto bg-muted animate-pulse rounded" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="h-96 bg-muted animate-pulse rounded-lg" data-testid={`skeleton-service-${i}`} />
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="servicos" className="py-20 md:py-32 bg-background relative" data-testid="section-services">
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1a1a1a_1px,transparent_1px),linear-gradient(to_bottom,#1a1a1a_1px,transparent_1px)] bg-[size:4rem_4rem] opacity-30" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 space-y-4">
          <h2 className="font-display font-bold text-4xl md:text-5xl lg:text-6xl uppercase tracking-tight" data-testid="text-services-title">
            Veja o que posso transformar
            <br />
            <span className="text-primary">na sua marca</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Transformo sua marca com design estratégico, pensado pra atrair, encantar e vender — tudo com visual profissional e preço acessível.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const Icon = iconMap[service.icon] || Sparkles;
            return (
              <Card
                key={service.id}
                className="p-8 bg-card border-card-border hover-elevate active-elevate-2 transition-all duration-300 hover:scale-105 group relative overflow-hidden min-h-[400px] flex flex-col"
                data-testid={`card-service-${index}`}
              >
                <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full blur-3xl group-hover:bg-primary/10 transition-colors" />
                
                <div className="relative z-10 flex flex-col h-full">
                  <div className="mb-6">
                    <div className="w-16 h-16 rounded-lg bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                      <Icon className="w-8 h-8 text-primary" />
                    </div>
                  </div>

                  <h3 className="font-display font-bold text-2xl mb-4 text-foreground" data-testid={`text-service-title-${index}`}>
                    {service.title}
                  </h3>

                  <p className="text-muted-foreground leading-relaxed mb-6 flex-grow" data-testid={`text-service-desc-${index}`}>
                    {service.description}
                  </p>

                  <div className="mt-auto">
                    <button className="text-primary font-medium text-sm uppercase tracking-wider inline-flex items-center gap-2 hover:gap-3 transition-all group/link">
                      Ver Exemplos
                      <span className="text-lg">→</span>
                    </button>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
