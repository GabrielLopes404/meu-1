import { Users, Paintbrush, Target } from "lucide-react";
import { Card } from "@/components/ui/card";

export function Differentiators() {
  const features = [
    {
      icon: Paintbrush,
      title: "Seu Estilo, Sua Marca",
      description: "Criações alinhadas com sua visão e estilo.",
      detail: "Resultados únicos, feitos sob medida pra sua marca.",
    },
    {
      icon: Target,
      title: "Design do Seu Jeito",
      description: "Você participa de cada etapa do processo.",
      detail: "Desenvolvemos juntos até alcançar o resultado perfeito.",
    },
    {
      icon: Users,
      title: "Você no Centro de Tudo",
      description: "Seu feedback é essencial em cada decisão.",
      detail: "Trabalho colaborativo que garante sua satisfação total.",
    },
  ];

  return (
    <section className="py-20 md:py-32 bg-background" data-testid="section-differentiators">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 space-y-4">
          <h2 className="font-display font-bold text-4xl md:text-5xl lg:text-6xl uppercase tracking-tight">
            Um Pouco do que <span className="text-primary">já Fiz</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card
              key={index}
              className="p-8 bg-card border-card-border text-center hover-elevate active-elevate-2 transition-all duration-300 hover:scale-105 group"
              data-testid={`card-differentiator-${index}`}
            >
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-primary/10 group-hover:bg-primary/20 transition-colors mb-6">
                <feature.icon className="w-10 h-10 text-primary" />
              </div>

              <h3 className="font-display font-bold text-2xl mb-3" data-testid={`text-differentiator-title-${index}`}>
                {feature.title}
              </h3>

              <p className="text-muted-foreground mb-2" data-testid={`text-differentiator-desc-${index}`}>
                {feature.description}
              </p>

              <p className="text-sm text-muted-foreground/80" data-testid={`text-differentiator-detail-${index}`}>
                {feature.detail}
              </p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
