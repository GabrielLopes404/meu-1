import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { X } from "lucide-react";
import type { PortfolioItem } from "@shared/schema";

const categories = ["Todos", "Identidade Visual", "Social Media", "3D", "Web/App"];

export function Portfolio() {
  const [activeFilter, setActiveFilter] = useState("Todos");
  const [selectedItem, setSelectedItem] = useState<PortfolioItem | null>(null);

  const { data: items = [], isLoading } = useQuery<PortfolioItem[]>({
    queryKey: ["/api/portfolio"],
  });

  const filteredItems =
    activeFilter === "Todos"
      ? items
      : items.filter((item) => item.category === activeFilter);

  if (isLoading) {
    return (
      <section id="portfolio" className="py-20 md:py-32 bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="h-12 w-64 mx-auto bg-muted animate-pulse rounded mb-16" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="h-80 bg-muted animate-pulse rounded-lg" />
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <>
      <section id="portfolio" className="py-20 md:py-32 bg-card" data-testid="section-portfolio">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 space-y-4">
            <h2 className="font-display font-bold text-4xl md:text-5xl lg:text-6xl uppercase tracking-tight" data-testid="text-portfolio-title">
              Meu Portfolio de <span className="text-primary">Impacto</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Um pouco do que já fiz — criações que transformam marcas em experiências memoráveis
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 mb-12">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveFilter(category)}
                className={`px-6 py-2 rounded-full font-medium text-sm uppercase tracking-wider transition-all ${
                  activeFilter === category
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                }`}
                data-testid={`filter-${category.toLowerCase().replace(/\//g, "-")}`}
              >
                {category}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredItems.length === 0 ? (
              <div className="col-span-full text-center py-20">
                <p className="text-muted-foreground text-lg">Nenhum projeto encontrado nesta categoria.</p>
              </div>
            ) : (
              filteredItems.map((item, index) => (
                <Card
                  key={item.id}
                  className="group relative overflow-hidden cursor-pointer aspect-square hover-elevate active-elevate-2 transition-all duration-300 hover:scale-105"
                  onClick={() => setSelectedItem(item)}
                  data-testid={`portfolio-item-${index}`}
                >
                  <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-10" />
                  
                  <div className="absolute inset-0 flex items-end justify-center p-6 z-20 translate-y-8 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
                    <div className="text-center space-y-2">
                      <Badge className="mb-2" data-testid={`badge-category-${index}`}>{item.category}</Badge>
                      <h3 className="font-display font-bold text-xl text-foreground" data-testid={`text-portfolio-title-${index}`}>{item.title}</h3>
                      {item.client && (
                        <p className="text-sm text-muted-foreground" data-testid={`text-portfolio-client-${index}`}>{item.client}</p>
                      )}
                    </div>
                  </div>

                  <div
                    className="absolute inset-0 bg-cover bg-center"
                    style={{ backgroundImage: `url(${item.imageUrl})` }}
                  />
                </Card>
              ))
            )}
          </div>
        </div>
      </section>

      <Dialog open={!!selectedItem} onOpenChange={() => setSelectedItem(null)}>
        <DialogContent className="max-w-4xl p-0 overflow-hidden bg-background border-border">
          {selectedItem && (
            <div className="relative" data-testid="lightbox-modal">
              <button
                onClick={() => setSelectedItem(null)}
                className="absolute top-4 right-4 z-50 p-2 rounded-full bg-background/80 backdrop-blur-sm hover:bg-background transition-colors"
                data-testid="button-close-lightbox"
              >
                <X className="w-6 h-6" />
              </button>
              
              <div className="aspect-square w-full">
                <img
                  src={selectedItem.imageUrl}
                  alt={selectedItem.title}
                  className="w-full h-full object-cover"
                />
              </div>
              
              <div className="p-8 space-y-4">
                <div className="flex items-center gap-3">
                  <Badge data-testid="badge-lightbox-category">{selectedItem.category}</Badge>
                  {selectedItem.client && (
                    <span className="text-sm text-muted-foreground" data-testid="text-lightbox-client">{selectedItem.client}</span>
                  )}
                </div>
                <h3 className="font-display font-bold text-3xl text-foreground" data-testid="text-lightbox-title">
                  {selectedItem.title}
                </h3>
                {selectedItem.description && (
                  <p className="text-muted-foreground leading-relaxed" data-testid="text-lightbox-description">
                    {selectedItem.description}
                  </p>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
