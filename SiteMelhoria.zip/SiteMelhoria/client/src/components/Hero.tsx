import { Button } from "@/components/ui/button";
import { ArrowDown, Sparkles } from "lucide-react";
import { SiInstagram } from "react-icons/si";

export function Hero() {
  const scrollToPortfolio = () => {
    const element = document.getElementById("portfolio");
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-background" data-testid="section-hero">
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1a1a1a_1px,transparent_1px),linear-gradient(to_bottom,#1a1a1a_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_80%_50%_at_50%_0%,#000_70%,transparent_110%)]" />
      
      <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-transparent to-transparent" />
      
      <div className="absolute top-20 left-10 w-72 h-72 bg-primary/20 rounded-full blur-[100px] animate-float" />
      <div className="absolute bottom-20 right-10 w-96 h-96 bg-primary/10 rounded-full blur-[120px] animate-float" style={{ animationDelay: "-3s" }} />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-16 text-center">
        <div className="space-y-8">
          <div className="space-y-4">
            <h1 className="font-display font-bold text-6xl sm:text-7xl md:text-8xl lg:text-9xl tracking-tight" data-testid="text-hero-title">
              <span className="block text-foreground uppercase" style={{ letterSpacing: "-0.02em" }}>
                DESIGNER
              </span>
              <span className="block text-transparent bg-clip-text bg-gradient-to-r from-primary via-primary to-primary/80 uppercase relative inline-block" style={{ letterSpacing: "-0.02em" }}>
                GRÁFICO
                <div className="absolute -bottom-2 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-primary to-transparent" />
              </span>
            </h1>
          </div>

          <p className="max-w-2xl mx-auto text-lg sm:text-xl text-muted-foreground font-body leading-relaxed" data-testid="text-hero-subtitle">
            Por trás de cada arte que você vê aqui, existe um processo estratégico que já impulsionou{" "}
            <span className="text-primary font-semibold">mais de 350 projetos</span> — e o próximo pode ser o seu.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <a
              href="https://www.instagram.com/lopesdesigner_ofc/"
              target="_blank"
              rel="noopener noreferrer"
              data-testid="button-cta-hero"
            >
              <Button size="lg" className="text-base px-8 py-6 relative overflow-hidden group">
                <span className="relative z-10 flex items-center gap-2">
                  <Sparkles className="w-5 h-5" />
                  PEDIR MEU PROJETO PERSONALIZADO
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-primary/0 via-primary/20 to-primary/0 opacity-0 group-hover:opacity-100 transition-opacity animate-pulse-glow" />
              </Button>
            </a>
          </div>

          <div className="pt-12">
            <button
              onClick={scrollToPortfolio}
              className="inline-flex flex-col items-center gap-2 text-muted-foreground hover:text-primary transition-colors group"
              data-testid="button-scroll-down"
            >
              <span className="text-xs uppercase tracking-widest font-medium">Veja o que posso fazer</span>
              <ArrowDown className="w-5 h-5 animate-bounce" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
